package Pharmacy;


import java.sql.*;
import java.util.Scanner;
import java.sql.Connection;                                 
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PharmacyStockManagement {
    private static final String URL = "jdbc:mysql://localhost:3306/pharmacy";
    private static final String USER = "root"; // Change as per your MySQL setup
    private static final String PASSWORD = "cse23"; // Change as per your MySQL setup

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            System.out.println("Connected to Database!");

            while (true) {
                System.out.println("\nPharmacy Stock Management");
                System.out.println("1. Add Medicine");
                System.out.println("2. View Medicines");
                System.out.println("3. Update Medicine");
                System.out.println("4. Delete Medicine");
                System.out.println("5. Purchase Medicine & Generate Bill");
                System.out.println("6. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1 : addMedicine(conn, scanner);
                    break;
                    case 2 : viewMedicines(conn);
                    break;
                    case 3 : updateMedicine(conn, scanner);
                    break;
                    case 4 : deleteMedicine(conn, scanner);
                    break;
                    case 5 : purchaseMedicine(conn, scanner);
                    break;
                    case 6 : 
                        System.out.println("Exiting program...");
                        break;
                    
                    default: 
                    	System.out.println("Invalid choice! Try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addMedicine(Connection conn, Scanner scanner) throws SQLException {
        System.out.print("Enter Medicine Id: ");
        int id = scanner.nextInt();
        System.out.print("Enter Medicine Name: ");
        scanner.nextLine(); // Consume newline
        String name = scanner.nextLine();
        System.out.print("Enter Category: ");
        String category = scanner.nextLine();
        System.out.print("Enter Quantity: ");
        int quantity = scanner.nextInt();
        System.out.print("Enter Price per unit: ");
        double price = scanner.nextDouble();

        // Insert `quantity_sold` as 0 and `total_revenue` as 0
        String sql = "INSERT INTO medicine (id, name, category, quantity, price, quantity_sold, total_revenue) VALUES (?, ?, ?, ?, ?, 0, 0)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.setString(2, name);
            stmt.setString(3, category);
            stmt.setInt(4, quantity);
            stmt.setDouble(5, price);
            stmt.executeUpdate();
            System.out.println("Medicine added successfully with initial quantity_sold=0 and total_revenue=0!");
        }
    }

    private static void viewMedicines(Connection conn) throws SQLException {
        String sql = "SELECT * FROM medicine";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            System.out.println("\nMedicine Stock:");
            System.out.printf("%-5s %-20s %-15s %-10s %-10s %-10s %-20s%n",
                    "ID", "Name", "Category", "Quantity", "Sold", "Price", "Total Revenue");
            while (rs.next()) {
                System.out.printf("%-5d %-20s %-15s %-10d %-10d %-10.2f %-20.2f%n",
                        rs.getInt("id"), rs.getString("name"), rs.getString("category"),
                        rs.getInt("quantity"), rs.getInt("quantity_sold"),
                        rs.getDouble("price"), rs.getDouble("total_revenue"));
            }
        }
    }

    private static void updateMedicine(Connection conn, Scanner scanner) throws SQLException {
        System.out.print("Enter Medicine name to update: ");
        String name = scanner.next();
        System.out.print("Enter New Quantity: ");
        int quantity = scanner.nextInt();
        System.out.print("Enter New Price: ");
        double price = scanner.nextDouble();

        String sql = "UPDATE medicine SET quantity = ?, price = ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, quantity);
            stmt.setDouble(2, price);
            stmt.setString(3, name);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Medicine updated successfully!");
            } else {
                System.out.println("Medicine ID not found.");
            }
        }
    }

    private static void deleteMedicine(Connection conn, Scanner scanner) throws SQLException {
        System.out.print("Enter Medicine ID to delete: ");
        int id = scanner.nextInt();

        String sql = "DELETE FROM medicine WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Medicine deleted successfully!");
            } else {
                System.out.println("Medicine ID not found.");
            }
        }
    }

    private static void purchaseMedicine(Connection conn, Scanner scanner) throws SQLException {
        System.out.print("Enter Medicine Name to purchase: ");
        scanner.nextLine(); // Consume newline
        String name = scanner.nextLine(); // Medicine name input

        // Query using name instead of id
        String checkSql = "SELECT * FROM medicine WHERE name = ?";
        
        try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            checkStmt.setString(1, name);  // Using name as a parameter
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next()) {
                    int id = rs.getInt("id"); // Fetch ID from database
                    int availableQuantity = rs.getInt("quantity");
                    double pricePerUnit = rs.getDouble("price");
                    int previousSold = rs.getInt("quantity_sold");
                    double previousRevenue = rs.getDouble("total_revenue");

                    System.out.print("Enter quantity to buy: ");
                    int quantity = scanner.nextInt();

                    if (quantity > availableQuantity) {
                        System.out.println("Not enough stock available!");
                        return;
                    }

                    // Calculate new total revenue and quantity sold
                    double saleAmount = quantity * pricePerUnit;
                    int newQuantitySold = previousSold + quantity;
                    double newTotalRevenue = previousRevenue + saleAmount;

                    // Update medicine stock
                    String updateSql = "UPDATE medicine SET quantity = quantity - ?, quantity_sold = ?, total_revenue = ? WHERE name = ?";
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                        updateStmt.setInt(1, quantity);
                        updateStmt.setInt(2, newQuantitySold);
                        updateStmt.setDouble(3, newTotalRevenue);
                        updateStmt.setString(4, name); // Using name instead of id
                        updateStmt.executeUpdate();
                    }

                    // Generate Bill
                    System.out.println("\n========== BILL ==========");
                    System.out.printf("Medicine: %s%n", name);
                    System.out.printf("Quantity: %d%n", quantity);
                    System.out.printf("Price per unit: %.2f%n", pricePerUnit);
                    System.out.printf("Total Amount: %.2f%n", saleAmount);
                    System.out.println("==========================");
                } else {
                    System.out.println("Medicine Name not found.");
                }
            }
        }
    }
}